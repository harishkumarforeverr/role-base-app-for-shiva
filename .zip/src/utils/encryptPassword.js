import CryptoJS from "crypto-js";
const secretKey = "mySecretkey123";

//encrypt the password
export const getEncryptedPassword = (password) =>
  CryptoJS.AES.encrypt(password, secretKey).toString();

//decrypt the password
export const getDecryptedPassword = (encryptedPassword) => {
  var decrypted = CryptoJS.AES.decrypt(encryptedPassword, secretKey);
  return decrypted.toString(CryptoJS.enc.Utf8);
};
