import { INITIAL_STORE_STATE } from "../utils/constant";
import { TYPES } from "./types";

function rootReducer(state = INITIAL_STORE_STATE, action) {
  switch (action.type) {
    case TYPES.LOGIN:
      return {
        ...state,
        ...action.payload,
      };
    case TYPES.UPDATE_PROFILE:
      return {
        ...state,
        profile: action.payload,
        updating: true,
      };
    case TYPES.DASHBOARD_PROFILE:
      return {
        ...state,
        dashboardProfile: action.payload,
      };
    case TYPES.ADD_USER:
      return {
        ...state,
        profile: INITIAL_STORE_STATE.profile,
        updating: false,
      };
    case TYPES.ADD_NEW_USER_STORE:
      return {
        ...state,
        usersList: action.payload,
      };
    //
    default:
      return state;
  }
}

export default rootReducer;
