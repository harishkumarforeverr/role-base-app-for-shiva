import {
  addUser,
  getAllUser, 
  getUserById,
  updateUserById,
  deleteUser,
} from "../service/user"; 
import { TYPES } from "./types";

 export const getUserInfomation = (id, navigateHandler, role) => {
  return async (dispatch) => {
    let result = [];

    result = await getUserById(id, role);

    dispatch({
      type: TYPES.UPDATE_PROFILE,
      payload: result[0],
    });
    navigateHandler();
  };
};
export const getUserProfile = (id, role) => {
  return async (dispatch) => {
    let result = [];
    result = await getUserById(id, role);
    dispatch({
      type: TYPES.DASHBOARD_PROFILE,
      payload: result[0],
    });
  };
};

export const dispatchUserCreation = (navigateHandler) => {
  return async (dispatch) => {
    dispatch({
      type: TYPES.ADD_USER,
    });
    navigateHandler();
  };
};
export const updateUserInfomation = (id, data, navigateHandler, role) => {
  return async (dispatch) => {
    let result = [];
    result = await updateUserById(id, { ...data, role });
    dispatch({
      type: TYPES.UPDATE_PROFILE,
      payload: result.data,
    });
    navigateHandler();
  };
};

export const updateGetUserList = (id, data, navigateHandler, role) => {
  return async (dispatch) => {
    await updateUserById(id, { ...data, role });
    const usersList = await getAllUser();
    dispatch({
      type: TYPES.ADD_NEW_USER_STORE,
      payload: usersList,
    });
    navigateHandler();
  };
};

export const addNewUserInfomation = (data, navigateHandler, role) => {
  return async (dispatch) => {
    await addUser({ ...data, role });
    const usersList = await getAllUser();
    dispatch({
      type: TYPES.ADD_NEW_USER_STORE,
      payload: usersList,
    });
    navigateHandler();
  };
};

export const getUserList = () => {
  return async (dispatch) => {
    const usersList = await getAllUser();
    dispatch({
      type: TYPES.ADD_NEW_USER_STORE,
      payload: [...usersList],
    });
  };
};

export const deleteUserFromList = (id, getUpdatedUserList) => {
  return async (dispatch) => {
    await deleteUser(id);
    getUpdatedUserList();
  };
};
